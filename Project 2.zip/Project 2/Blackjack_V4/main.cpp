/* 
 * File:   main.cpp
 * Author: Cuong Nguyen
 * Created on December 6th, 2018 2:00 PM
 * Purpose: Black Jack Game
 */

//System Libraries

#include <iostream>//Input-Output Library
#include <ctime>//Time for rand

using namespace std;//Name-space under which system libraries exist

//Global Constants

//Struct
struct Card {
    int value;
    string suit;
    string name;
    bool taken;
};

//Function Prototypes
Card dealCrd (string[], int);
string dealSt (string[], int);
int getValue( Card hand[], int ncards );
int getNumAces( Card hand[], int ncards );
Card DrawCard( string[], string[], Card[], int, int, int );

//Execution Begins Here!

int main(int argc, char** argv) {  

//Set the random number seed  declare variables
    srand(time(0));
// Declare variables
    const int SIZE1=13,//Size of card array
              SIZE2=4;//Size of suit array
    const int DECK_SIZE = SIZE1 * SIZE2,//Deck of cards size
              ncards=1;//The first card
    string    name,//Name of the player
              card[]={"Ace","2","3","4","5","6","7",
                  "8","9","10","Jack","Queen","King"},
              suit[]={"of Hearts","of Diamonds","of Spades","of Clubs"};
    Card      hand[10], dealer[10];
    Card      taken[DECK_SIZE];
    int       choice,//Choices from the Game Menu
              value1,//Value of player's first card
              value2,//Value of player's second card
              value3,//Value of player's additional cards
              value4,//Value of house's first cards
              value5,//Value of house's second card
              value6,//Value of house's additional cards
              totalV,//Total value of player's cards
              hValue,//Total value of house's cards
              naces1,//Value of Aces for player's first card
              naces2,//Value of Aces for player's second card
              naces3,//Value of Aces for house's first card
              naces4;//Value of Aces for house's second card
    char      ans,//Yes or No for another card
              ans2;//Yes or No for another game   
    
//Initialize or input here
 
//Game Menu    
    cout<<"This is a Blackjack game\n";
    cout<<"Please input your name\n";
    cin>>name;
 do{    
    cout<<"Game Menu:\n";
    cout<<"1. Play Blackjack\n";
    cout<<"2. Exit Game\n";
    cout<<"Please enter your choice ";
    cin>>choice;   

//Process/Calculations Here
    switch (choice){
        case 1:
                //Initialize taken array;
                for( int i = 0; i < DECK_SIZE; i++ ){
                    taken[i].suit = suit[i/13];
                    taken[i].value = i % 13;
                    taken[i].taken = false;
                }
                //Call card's functions
                cout<<endl;
                cout<<"You've been dealt with "<<endl;
                //Player's first card
                hand[0] = DrawCard(card,suit,taken,SIZE1,SIZE2,DECK_SIZE);
                cout<< hand[0].name <<' '<<hand[0].suit<<"||";
                //Player's second card
                hand[1] = DrawCard(card,suit,taken,SIZE1,SIZE2,DECK_SIZE);
                cout<< hand[1].name <<' '<< hand[1].suit<<endl;
                //Player's first two cards value
                value1=getValue(hand, ncards);
                value2=getValue(hand, ncards+1);
                //Setting value for aces cards
                naces1=getNumAces(hand, ncards );
                naces2=getNumAces(hand, ncards+1 );
                if(naces1==1&&naces2==1){
                    value1+=10;
                    value2+=9;
                }
                else if(naces1==1 && naces2==0){
                    value1+=10;
                }
                else if(naces1==0 && naces2==1){
                    value2+=10;
                }
               
                totalV=value1+value2;
                //cout<<endl<<"value1 ="<<value1<<endl;
                cout<<"Your score is "<<totalV<<endl;
                //If score is equal 21 for the first two cards
                if (totalV==21)
                    cout<<"Black jack!!!"<<endl;
                //If score is less than 21
                else{
                      bool busted = false;
                      do{    
                        cout<<"Would you like another card?"<<endl;
                        cout<<"Please enter y for Yes and n for No ";
                        cin>>ans;
                    //Validation user's input
                        if(ans!='y' && ans!='n'){
                          cout<<"Your answer is invalid\n";  
                          cout<<"Please play again"<<endl;
                          return 1;
                        }
                    //Answer is yes
                        else if (ans=='y'){
                            //Additional cards
                            hand[2] = DrawCard(card,suit,taken, 
                                               SIZE1,SIZE2,DECK_SIZE);
                            cout<<hand[2].name <<' '<< hand[2].suit<<endl;
                            //Additional cards value
                            value3=getValue(hand,ncards+2);
                            totalV+=value3;
                            cout<<"Now your score is "<<totalV<<endl;
                            if (totalV>21){
                                busted = true;
                                cout<<"Bust!"<<endl;
                            }    
                        }    
                      }while( ! busted && ans == 'y' );
                    }  
                //House's hand
                cout<<endl;
                cout<<"The House has been dealt the following cards:\n";
                hand[3] = DrawCard(card,suit,taken, 
                                   SIZE1,SIZE2,DECK_SIZE);
                cout<<hand[3].name <<' '<< hand[3].suit;
                cout<<"||";
                hand[4] = DrawCard(card,suit,taken, 
                                   SIZE1,SIZE2,DECK_SIZE);
                cout<<hand[4].name <<' '<< hand[4].suit;
                cout<<"||";
                value4=getValue(hand,ncards+3);
                value5=getValue(hand,ncards+4);
                hValue=value4+value5;
                //Setting value for aces cards
                naces3= getNumAces(hand, ncards+3 );
                naces4= getNumAces(hand, ncards+4 );
                if(naces3==1 && naces4==1){
                    value4+=10;
                    value5+=9;
                    totalV=value4+value5;
                }
                else if(naces3==1){
                    value1+=10;
                    totalV=value4+value5;
                }
                else if(naces4==1){
                    value2+=10;
                    hValue=value4+value5;
                }
                else{ 
                    hValue=value4+value5;
                }
               
                do{
                   hand[5] = DrawCard(card,suit,taken, 
                                   SIZE1,SIZE2,DECK_SIZE);
                   cout<<hand[5].name <<' '<< hand[5].suit;
                   cout<<"||";
                   value6=getValue(hand,ncards+5);
                   hValue+=value6;
                }while(hValue<16);
                cout<<"\n";
                cout<<"The house score is: "<<hValue<<endl;
                //Determine who the winner is
                if(hValue<totalV && (hValue<21 && totalV<21)){
                    cout<<endl;
                    cout<<"Congratulations!!! You win\n"<<endl;
                }
                else if(hValue>totalV && (hValue<21 && totalV<21)){
                    cout<<endl;
                    cout<<"House wins\n";
                }
                else if(hValue>21 && totalV<=21){
                    cout<<endl;
                    cout<<"Congratulations!!! You win\n";
                }
                else if(hValue<=21 && totalV>21){
                    cout<<endl;
                    cout<<"House wins\n";
                }
                else if(hValue>21 && totalV>21){
                    cout<<endl;
                    cout<<"Push!\n";
                }   
                else{ 
                    cout<<endl;
                    cout<<"Push!\n";
                }
        break;
        
        case 2:
            cout<<"Good-bye!!!"<<endl;
            break;
    }
    cout<<endl;
  }while( choice == 1 );
  
 //Exit the program
  return 0;
}


Card dealCrd (string card[], int Size){
    Size=rand()%13;
    Card c;
    c.name = card[Size];
    c.value = Size;
    return c;
}


string dealSt (string suit[], int Size){
    Size=rand()%4;
    return suit[Size];
}



int getValue( Card hand[], int ncards ) {
    int total = 0;
    for( int i = 0; i < ncards; i++ ) {
        int value = hand[i].value + 1;
        if( value > 10 ) value = 10;
        total = value;
    }
    return total;
}


int getNumAces( Card hand[], int ncards ) {
    int total = 0;
    for( int i = 0; i < ncards; i++ ) {
        int value = hand[i].value;
        if( value == 0 ) total++;
    }
    return total;    
}


Card DrawCard( string card[], string suit[], Card taken[],
               int Size1, int Size2, int Size3 ) {
    Card c;
    bool selected;
    do {
        c = dealCrd(card,Size1);
        c.suit = dealSt(suit,Size2);
        selected = false;
                for( int i = 0; i < Size3; i++ ) {
                    if( c.suit == taken[i].suit &&
                        c.value == taken[i].value ) {
                          if( taken[i].taken )
                                selected = true;
                          else taken[i].taken = true;
                      }
                  }
    } while( selected );
    return c;
}
