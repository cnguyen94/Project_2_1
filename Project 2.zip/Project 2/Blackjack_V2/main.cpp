/* 
 * File:   main.cpp
 * Author: Cuong Nguyen
 * Created on December 4th, 2018 9:00 PM
 * Purpose: Black Jack Game
 */

//System Libraries

#include <iostream>//Input-Output Library
#include <ctime>//Time for rand
#include <cstdlib>  //
using namespace std;//Name-space under which system libraries exist

//Global Constants

//structs
struct Card {
    int value;
    string suit;
    string name;
    bool taken;
};

//Function Prototypes
Card dealCrd1 (string[], int);
string dealSt1    (string[], int);
void dealCrd2 (string[], int);
void dealSt2    (string[], int);
int getValue( Card hand[], int ncards );
int getNumAces( Card hand[], int ncards );
Card DrawCard( string[], string[], Card[], int, int, int );

//Execution Begins Here!

int main(int argc, char** argv) {  

//Set the random number seed  declare variables
    srand(time(0));
// Declare variables
    const int SIZE1=13,//Size of card array
           SIZE2=4;//Size of suit array
    const int DECK_SIZE = SIZE1 * SIZE2;//Deck of cards size
    string name,//Name of the player
           card[]={"Ace","2","3","4","5","6","7",
                  "8","9","10","Jack","Queen","King"},
           suit[]={"of Hearts","of Diamonds","of Spades","of Clubs"};
    Card   hand[10], dealer[10];
    Card   taken[DECK_SIZE];
    int    ncards,//Number of player's initial cards
           choice,//Choices from the Game Menu
           value,//Values of cards
           naces;//Value of Aces cards
    char   ans,//Yes or No for another card
           ans2;//Yes or No for another game   
    
//Initialize or input here
 
//Game Menu    
    cout<<"This is a Blackjack game\n";
    cout<<"Please input your name\n";
    cin>>name;
 do{    
    cout<<"Game Menu:\n";
    cout<<"1. Play Blackjack\n";
    cout<<"2. Exit Game\n";
    cout<<"Please enter your choice\n";
    cin>>choice;   

//Process/Calculations Here
    switch (choice){
        case 1:
                 //Initialize taken array;
                for( int i = 0; i < DECK_SIZE; i++ ) {
                    taken[i].suit = suit[i/13];
                    taken[i].value = i % 13;
                    taken[i].taken = false;
                }
                //Initialize number of cards player first has
                ncards = 2;
                //Call card's functions
                cout<<"You've been dealt with "<<endl;
                //Player's first card
                hand[0] = DrawCard( card, suit, taken, SIZE1, SIZE2, DECK_SIZE );
                cout<< hand[0].name << ' ' << hand[0].suit;
                //Player's second card
                cout<<" and ";
                hand[1] = DrawCard( card, suit, taken, SIZE1, SIZE2, DECK_SIZE );
                cout<< hand[1].name << ' ' << hand[1].suit;
                //dealCrd2(card,SIZE1);
                //cout<<' ';
                //dealSt2(suit,SIZE2);
                cout<<endl;
                
                
                //Check if player's hand == 21, if so print 'BlackJack!', then break.
                value = getValue( hand, ncards );
                naces = getNumAces( hand, ncards );
                if (naces==1)
                    value+=10;
                cout<<"Your score is "<<value<<endl;
                cout<<endl;
                //Check if value == 21, if so print BlackJack!
                //else ..
                // i = 2;
                // Loop asking if player wants another card {
                  // if so add another card to hand[i]. Increment i;
                  // If they wanted a card or not, Check if value > 21, if so they busted so exit loop.
               //}



              //Dealer's loop.
                
              //value = getValue( dealer, ncards );
              //naces = getNumAces( dealer, ncards );

             //Compare player & dealer hands.
             //remember to check if they have aces -- if so, add 10 to value
        
            //print message who won, or if it's a push
                break;
        case 2:
            cout<<"Good-bye!!!"<<endl;
            break;
    }
  } while( choice == 1 );
  
 //Exit the program
  return 0;
}

Card dealCrd1 (string card[], int Size){
    Size=rand()%13;
    Card c;
    c.name = card[Size];
    c.value = Size;
    return c;
}

string dealSt1 (string suit[], int Size){
    Size=rand()%4;
    return suit[Size];
}



int getValue( Card hand[], int ncards ) {
    int total = 0;
    for( int i = 0; i < ncards; i++ ) {
        int value = hand[i].value + 1;
        if( value > 10 ) value = 10;
        total += value;
    }
    return total;
}

int getNumAces( Card hand[], int ncards ) {
    int total = 0;
    for( int i = 0; i < ncards; i++ ) {
        int value = hand[i].value;
        if( value == 0 ) total++;
    }
    return total;    
}

Card DrawCard( string card[], string suit[], Card taken[],
               int Size1, int Size2, int Size3 ) {
    Card c;
     bool selected;
    do {
                  c = dealCrd1(card,Size1);
                  c.suit = dealSt1(suit,Size2);
                  
                  selected = false;
                  for( int i = 0; i < Size3; i++ ) {
                      if( c.suit == taken[i].suit &&
                          c.value == taken[i].value ) {
                          if( taken[i].taken )
                                selected = true;
                          else taken[i].taken = true;
                      }
                  }
    } while( selected );
    
    return c;
}
