/* 
 * File:   main.cpp
 * Author: Cuong Nguyen
 * Created on December 5th, 2018 3:24 PM
 * Purpose: Black Jack Game
 */

//System Libraries

#include <iostream>//Input-Output Library
#include <ctime>//Time for rand

using namespace std;//Name-space under which system libraries exist

//Global Constants

//structs
struct Card {
    int value;
    string suit;
    string name;
    bool taken;
};

//Function Prototypes
Card dealCrd1 (string[], int);
string dealSt1    (string[], int);
void dealCrd2 (string[], int);
void dealSt2    (string[], int);
int getValue( Card hand[], int ncards );
int getNumAces( Card hand[], int ncards );
Card DrawCard( string[], string[], Card[], int, int, int );

//Execution Begins Here!

int main(int argc, char** argv) {  

//Set the random number seed  declare variables
    srand(time(0));
// Declare variables
    const int SIZE1=13,//Size of card array
              SIZE2=4;//Size of suit array
    const int DECK_SIZE = SIZE1 * SIZE2,//Deck of cards size
              ncards=1;//The frist card
    string    name,//Name of the player
              card[]={"Ace","2","3","4","5","6","7",
                  "8","9","10","Jack","Queen","King"},
              suit[]={"of Hearts","of Diamonds","of Spades","of Clubs"};
    Card      hand[10], dealer[10];
    Card      taken[DECK_SIZE];
    int       choice,//Choices from the Game Menu
              value1,//Value of player's first card
              value2,//Value of player's second card
              value3,//Value of player's additional cards
              totalV,//Total value of player's cards
              naces1,//Value of Aces for the frist card
              naces2;//Value of Aces for the second card
    char      ans,//Yes or No for another card
              ans2;//Yes or No for another game   
    
//Initialize or input here
 
//Game Menu    
    cout<<"This is a Blackjack game\n";
    cout<<"Please input your name\n";
    cin>>name;
 do{    
    cout<<"Game Menu:\n";
    cout<<"1. Play Blackjack\n";
    cout<<"2. Exit Game\n";
    cout<<"Please enter your choice\n";
    cin>>choice;   

//Process/Calculations Here
    switch (choice){
        case 1:
                //Initialize taken array;
                for( int i = 0; i < DECK_SIZE; i++ ) {
                    taken[i].suit = suit[i/13];
                    taken[i].value = i % 13;
                    taken[i].taken = false;
                }
                //Initialize number of cards player first has
               
                //Call card's functions
                cout<<"You've been dealt with "<<endl;
                //Player's first card
                hand[0] = DrawCard(card,suit,taken,SIZE1,SIZE2,DECK_SIZE);
                cout<< hand[0].name <<' '<<hand[0].suit;
                //Player's second card
                cout<<" and ";
                hand[1] = DrawCard(card,suit,taken,SIZE1,SIZE2,DECK_SIZE);
                cout<< hand[1].name <<' '<< hand[1].suit;
                cout<<endl;
                //Player's first two cards value
                value1=getValue(hand, ncards);
                value2=getValue(hand, ncards+1);
                //Setting value for aces cards
                naces1= getNumAces(hand, ncards );
                naces2= getNumAces(hand, ncards+1 );
                if(naces1==1 && naces2==1){
                    value1+=10;
                    value2+=9;
                    totalV=value1+value2;
                    cout<<"Your score is "<<totalV<<endl;
                }
                else if(naces1==1){
                    value1+=10;
                    totalV=value1+value2;
                    cout<<"Your score is "<<totalV<<endl;
                }
                else if(naces2==1){
                    value2+=10;
                    totalV=value1+value2;
                    cout<<"Your score is "<<totalV<<endl;
                }
                else{ 
                    totalV=value1+value2;
                    cout<<"Your score is "<<totalV<<endl;
                }
                //If score is equal 21 for the first two cards
                if (totalV==21)
                    cout<<"Black jack!!!"<<endl;
                //If score is less than 21
                else{
                      bool busted = false;
                      do{    
                        cout<<"Would you like another card?"<<endl;
                        cout<<"Please enter y for Yes and n for No ";
                        cin>>ans;
                    //Validation user's input
                        if(ans!='y' && ans!='n'){
                          cout<<"Your answer is invalid\n";  
                          cout<<"Please play again"<<endl;
                          return 1;
                        }
                    //Answer is yes
                        else if (ans=='y'){
                            //Additional cards
                            hand[2] = DrawCard(card,suit,taken, 
                                               SIZE1,SIZE2,DECK_SIZE);
                            cout<<hand[2].name <<' '<< hand[2].suit<<endl;
                            //Additional cards value
                            value3=getValue(hand,ncards+2);
                            totalV+=value3;
                            cout<<"Now your score is "<<totalV<<endl;
                            if (totalV>21){
                                busted = true;
                                cout<<"You busted!!!"<<endl;
                            }    
                        }    
                      }while( ! busted && ans == 'y' );
                    }  
                    
                
                //Check if value == 21, if so print BlackJack!
                //else ..
                // i = 2;
                // Loop asking if player wants another card {
                  // if so add another card to hand[i]. Increment i;
                  // If they wanted a card or not, Check if value > 21, if so they busted so exit loop.
               //}



              //Dealer's loop.
                
              //value = getValue( dealer, ncards );
              //naces = getNumAces( dealer, ncards );

             //Compare player & dealer hands.
             //remember to check if they have aces -- if so, add 10 to value
        
            //print message who won, or if it's a push
                break;
        
        case 2:
            cout<<"Good-bye!!!"<<endl;
            break;
    }
    cout<<endl;
  } while( choice == 1 );
  
 //Exit the program
  return 0;
}

Card dealCrd1 (string card[], int Size){
    Size=rand()%13;
    Card c;
    c.name = card[Size];
    c.value = Size;
    return c;
}

string dealSt1 (string suit[], int Size){
    Size=rand()%4;
    return suit[Size];
}



int getValue( Card hand[], int ncards ) {
    int total = 0;
    for( int i = 0; i < ncards; i++ ) {
        int value = hand[i].value + 1;
        if( value > 10 ) value = 10;
        total = value;
    }
    return total;
}

int getNumAces( Card hand[], int ncards ) {
    int total = 0;
    for( int i = 0; i < ncards; i++ ) {
        int value = hand[i].value;
        if( value == 0 ) total++;
    }
    return total;    
}

Card DrawCard( string card[], string suit[], Card taken[],
               int Size1, int Size2, int Size3 ) {
    Card c;
     bool selected;
    do {
                  c = dealCrd1(card,Size1);
                  c.suit = dealSt1(suit,Size2);
                  
                  selected = false;
                  for( int i = 0; i < Size3; i++ ) {
                      if( c.suit == taken[i].suit &&
                          c.value == taken[i].value ) {
                          if( taken[i].taken )
                                selected = true;
                          else taken[i].taken = true;
                      }
                  }
    } while( selected );
    
    return c;
}
