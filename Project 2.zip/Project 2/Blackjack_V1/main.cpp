/* 
 * File:   main.cpp
 * Author: Cuong Nguyen
 * Created on October 24th, 2018 5:15 PM
 * Purpose: Black Jack Game
 */

//System Libraries

#include <iostream>//Input-Output Library


using namespace std;//Name-space under which system libraries exist

//Global Constants

//Function Prototypes

//Execution Begins Here!

int main(int argc, char** argv) {  

//Set the random number seed  declare variables

// Declare variables
 
 string name;//Name of the player
 int  choice;
 char ans,//Yes or No for another card
      ans2;//Yes or No for another game   
    
//Initialize or input here
 
//Game Menu    
      cout<<"This is a Blackjack game\n";
      cout<<"Please input your name\n";
      cin>>name;
      cout<<"Game Menu:\n";
      cout<<"1. Play Blackjack\n";
      cout<<"2. Exit Game\n";
      cout<<"Please enter your choice\n";
      cin>>choice;   

//Process/Calculations Here
    switch (choice){
       while(ans2=='y'){
            case 1:
            break;
            case 2:     
            cout<<"Would you like to play another game? ";
            cin>>ans2;
            cout<<endl;        
        } 
            cout<<"Good-bye!!!"<<endl;
            break;
            default: cout<<"Good-bye!!!"<<endl;
    }
 //Exit the program
  return 0;
}

